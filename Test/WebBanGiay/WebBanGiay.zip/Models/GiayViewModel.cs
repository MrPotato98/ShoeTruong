﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebBanGiay.Models
{
    public class GiayViewModel
    {
        public IEnumerable<WebBanGiay.Models.GIAY> giay { get; set; }
    }
}